package com.TNSIF;

public class Overloading {
	int add(int a, int b) {
		System.out.println("1st method");
		return(a+b);
	}
	static int add(int a,int b,int c) {
		System.out.println("2nd method");
		return(a+b+c);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Overloading o = new Overloading();
		int d;
		d = o.add(12, 23);
		System.out.println("add = "+d);
		d = add(12, 23, 34);
		System.out.println("add = "+d);
	}

}
