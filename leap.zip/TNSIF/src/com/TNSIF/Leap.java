package com.TNSIF;
import java.time.Year;
import java.util.Scanner;

public class Leap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("year = ");
		int year = s.nextInt();
		boolean Leap = Year.of(year).isLeap();
		if(Leap) {
			System.out.println(year+"is leap");
		}
		else {
			System.out.println(year+"not a leap");
		}
		s.close();
	}

}