package com.TNSIF;

public class Cons {
	private String a;
	private String b;
	Cons(){
		a="anime";
		b="drama";
	}
	Cons(String z, String y){
		a=z;
		b=y;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cons c = new Cons();
		System.out.println(c.a);
		System.out.println(c.b);
		Cons co = new Cons("anime","drama");
		System.out.println(co.a);
		System.out.println(co.b);
	}

}
