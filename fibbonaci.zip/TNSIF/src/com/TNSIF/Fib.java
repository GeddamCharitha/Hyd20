package com.TNSIF;

public class Fib {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 10;
		int n1 = 0;
		int n2 = 1;
		System.out.println("fib series till"+n+"is:");
		
		for(int i = 0;i<=n;i++) {
			System.out.print(n1+",");
			int n3 = n1+n2;
			n1 = n2;
			n2=n3;
		}
		

	}

}
